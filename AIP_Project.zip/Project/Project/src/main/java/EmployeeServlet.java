import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import emp.DatabaseConnection;  // Ensure this is correct

@WebServlet("/Employee")
public class EmployeeServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String message = "";

        try (Connection con = DatabaseConnection.getConnection()) {
            if ("add".equals(action)) {
                PreparedStatement stmt = con.prepareStatement("INSERT INTO employee (name, department, salary) VALUES (?, ?, ?)");
                stmt.setString(1, request.getParameter("name"));
                stmt.setString(2, request.getParameter("department"));
                stmt.setInt(3, Integer.parseInt(request.getParameter("salary")));
                stmt.executeUpdate();
                message = "Employee added successfully!";
            } else if ("update".equals(action)) {
                PreparedStatement stmt = con.prepareStatement("UPDATE employee SET name=?, department=?, salary=? WHERE id=?");
                stmt.setString(1, request.getParameter("name"));
                stmt.setString(2, request.getParameter("department"));
                stmt.setInt(3, Integer.parseInt(request.getParameter("salary")));
                stmt.setInt(4, Integer.parseInt(request.getParameter("id")));
                stmt.executeUpdate();
                message = "Employee updated successfully!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }

        // Redirect with a success parameter
        response.sendRedirect("employee.jsp?message=" + message);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String message = "";

        try (Connection con = DatabaseConnection.getConnection()) {
            if ("delete".equals(action)) {
                PreparedStatement stmt = con.prepareStatement("DELETE FROM employee WHERE id=?");
                stmt.setInt(1, Integer.parseInt(request.getParameter("id")));
                stmt.executeUpdate();
                message = "Employee deleted successfully!";
            }
        } catch (SQLException e) {
            e.printStackTrace();
            message = "Error: " + e.getMessage();
        }

        // Redirect with success message
        response.sendRedirect("employee.jsp?message=" + message);
    }
}
